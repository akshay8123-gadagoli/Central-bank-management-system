from django.contrib import admin
from .models import *

admin.site.register(BasicDetails)
admin.site.register(PresentLocation)
admin.site.register(Status)
admin.site.register(MoneyTransfer)



